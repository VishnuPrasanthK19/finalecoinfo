import pandas as pd
from model_loader import predict_cost_efficiency, predict_co2

# Load dataset ONCE
df = pd.read_csv("data/processed/final_ecopack.csv")

def recommend_materials(top_n=5):
    print(">>> recommend_materials started")

    results = []

    for _, row in df.head(10).iterrows():   # ✅ CORRECT INDENTATION
        features = [
            row["Tensile_Strength_MPa"],
            row["Weight_Capacity_kg"],
            row["Biodegradability_Score"],
            row["Recyclability_Percent"],
            row["Moisture_Barrier_Grade"]
        ]

        cost_eff = predict_cost_efficiency(features)
        co2 = predict_co2(features)

        final_score = (
            cost_eff * 0.35 +
            row["Biodegradability_Score"] * 0.25 +
            row["Recyclability_Percent"] * 0.20 -
            co2 * 0.20
        )

        results.append({
            "Material_Type": row["Material_Type"],
            "Predicted_Cost_Efficiency": round(cost_eff, 2),
            "Predicted_CO2": round(co2, 2),
            "Final_Score": round(final_score, 2)
        })

    print(">>> recommend_materials finished")

    results = sorted(results, key=lambda x: x["Final_Score"], reverse=True)
    return results[:top_n]
