from flask import Flask, request, jsonify
from flask_cors import CORS
from model_loader import predict_cost_efficiency, predict_co2
from recommendation_engine import recommend_materials

app = Flask(__name__)
CORS(app)

@app.route("/")
def home():
    return "InfosysEcoPackAI Backend is Running"

@app.route("/predict", methods=["POST"])
def predict():
    data = request.json

    features = [
        data["Tensile_Strength_MPa"],
        data["Weight_Capacity_kg"],
        data["Biodegradability_Score"],
        data["Recyclability_Percent"],
        data["Moisture_Barrier_Grade"]
    ]

    cost_eff = predict_cost_efficiency(features)
    co2 = predict_co2(features)

    return jsonify({
        "predicted_cost_efficiency": round(cost_eff, 2),
        "predicted_co2_emission": round(co2, 2)
    })

@app.route("/recommend", methods=["GET"])
def recommend():
    results = recommend_materials(top_n=5)
    return jsonify(results)

if __name__ == "__main__":
    app.run(debug=True)
