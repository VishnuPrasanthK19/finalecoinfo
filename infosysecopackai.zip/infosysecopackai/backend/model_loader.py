import joblib
import pandas as pd

# Load trained models
cost_model = joblib.load("models/cost_rf_model.pkl")
co2_model = joblib.load("models/co2_xgb_model.pkl")

FEATURE_COLUMNS = [
    "Tensile_Strength_MPa",
    "Weight_Capacity_kg",
    "Biodegradability_Score",
    "Recyclability_Percent",
    "Moisture_Barrier_Grade"
]

def predict_cost_efficiency(features):
    X = pd.DataFrame([features], columns=FEATURE_COLUMNS)
    return float(cost_model.predict(X)[0])

def predict_co2(features):
    X = pd.DataFrame([features], columns=FEATURE_COLUMNS)
    return float(co2_model.predict(X)[0])
