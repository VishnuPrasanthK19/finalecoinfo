import os
import pandas as pd

# Ensure processed directory exists
os.makedirs("data/processed", exist_ok=True)

# Load cleaned dataset
df = pd.read_csv("data/processed/cleaned_ecopack.csv")

# -----------------------------
# Feature Engineering
# -----------------------------

# Cost Efficiency Proxy
# (Since no direct cost column exists, we derive efficiency from strength & capacity)
df["cost_efficiency"] = (
    df["Weight_Capacity_kg"] * df["Tensile_Strength_MPa"]
)

# CO2 Impact Index
df["co2_impact_index"] = (
    df["CO2_Emission_Score"] / df["Weight_Capacity_kg"]
)

# Sustainability Score
df["sustainability_score"] = (
    df["Biodegradability_Score"] * 0.4 +
    df["Recyclability_Percent"] * 0.3 -
    df["CO2_Emission_Score"] * 0.3
)

# Moisture adjusted durability score
df["durability_score"] = (
    df["Tensile_Strength_MPa"] * 0.6 +
    df["Moisture_Barrier_Grade"] * 0.4
)

# Save final dataset
df.to_csv("data/processed/final_ecopack.csv", index=False)

print("✅ Feature engineering completed successfully")
