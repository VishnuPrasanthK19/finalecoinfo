import pandas as pd

df = pd.read_excel("data/raw/Ecopack-dataset.xlsx")


print("Shape:", df.shape)
print("\nColumns:")
print(df.columns)

print("\nFirst 5 rows:")
print(df.head())

print("\nDataset Info:")
print(df.info())
