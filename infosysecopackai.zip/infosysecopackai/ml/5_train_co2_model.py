import pandas as pd
import xgboost as xgb
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, r2_score
import joblib
import os

# Load final dataset
df = pd.read_csv("data/processed/final_ecopack.csv")

# -----------------------------
# Feature & Target Selection
# -----------------------------
FEATURES = [
    "Tensile_Strength_MPa",
    "Weight_Capacity_kg",
    "Biodegradability_Score",
    "Recyclability_Percent",
    "Moisture_Barrier_Grade"
]

TARGET = "CO2_Emission_Score"

X = df[FEATURES]
y = df[TARGET]

# -----------------------------
# Train-Test Split
# -----------------------------
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# -----------------------------
# Train XGBoost Model
# -----------------------------
model = xgb.XGBRegressor(
    n_estimators=300,
    learning_rate=0.05,
    max_depth=5,
    objective="reg:squarederror",
    random_state=42
)

model.fit(X_train, y_train)

# -----------------------------
# Evaluation
# -----------------------------
pred = model.predict(X_test)

print("XGBoost – CO₂ Emission Model")
print("MAE:", mean_absolute_error(y_test, pred))
print("R2 Score:", r2_score(y_test, pred))

# -----------------------------
# Save Model
# -----------------------------
os.makedirs("models", exist_ok=True)
joblib.dump(model, "models/co2_xgb_model.pkl")

print("✅ CO₂ emission model saved successfully")
