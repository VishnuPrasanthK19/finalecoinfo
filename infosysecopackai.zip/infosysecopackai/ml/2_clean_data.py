import pandas as pd

df = pd.read_excel("data/raw/Ecopack-dataset.xlsx")


# Remove duplicates
df.drop_duplicates(inplace=True)

# Fill numeric missing values
num_cols = df.select_dtypes(include="number").columns
df[num_cols] = df[num_cols].fillna(df[num_cols].mean())

# Fill categorical missing values
cat_cols = df.select_dtypes(include="object").columns
df[cat_cols] = df[cat_cols].fillna("Unknown")

# Save cleaned data
df.to_csv("data/processed/cleaned_ecopack.csv", index=False)

print("✅ Data cleaning completed")
