const API_URL = "http://127.0.0.1:5000";

function predict() {
    const data = {
        Tensile_Strength_MPa: Number(document.getElementById("tensile").value),
        Weight_Capacity_kg: Number(document.getElementById("weight").value),
        Biodegradability_Score: Number(document.getElementById("bio").value),
        Recyclability_Percent: Number(document.getElementById("recycle").value),
        Moisture_Barrier_Grade: Number(document.getElementById("moisture").value)
    };

    fetch(`${API_URL}/predict`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data)
    })
    .then(res => res.json())
    .then(result => {
        document.getElementById("cost").textContent =
            result.predicted_cost_efficiency;

        document.getElementById("co2").textContent =
            result.predicted_co2_emission;

        const badge = document.getElementById("badge");
        const co2 = result.predicted_co2_emission;

        if (co2 <= 1.5) {
            badge.textContent = "Eco-Friendly";
            badge.className = "green";
        } else if (co2 <= 3) {
            badge.textContent = "Moderate Impact";
            badge.className = "yellow";
        } else {
            badge.textContent = "High Impact";
            badge.className = "red";
        }
    });
}

function recommend() {
    fetch(`${API_URL}/recommend`)
    .then(res => res.json())
    .then(result => {
        const tableBody = document.querySelector("#recTable tbody");
        tableBody.innerHTML = "";

        result.forEach((item, index) => {
            const row = `
                <tr>
                    <td>${index + 1}</td>
                    <td>${item.Material_Type}</td>
                    <td>${item.Final_Score}</td>
                    <td>${item.Predicted_CO2}</td>
                    <td>${item.Predicted_Cost_Efficiency}</td>
                </tr>
            `;
            tableBody.innerHTML += row;
        });
    });
}
